# Source archive — The inscribed parabola and the Poncelet point (Paper F)

- `paperf.tex`, `paperf.pdf` — the paper.
- Lean sources: https://github.com/jpbald93/quadparabola (commit f85c7bbdbf527c37b940d2331e6d720f01d221db) and
  https://github.com/jpbald93/quadrangle (commit 4153ce0b11533a95060eb4f1a25e54708fa13875); Lean v4.33.1, Mathlib 0df444a3.
- `reports/` — statement-level battery reports (main files, extended, final repositories, both machines), build reports,
  prior-art sweep, fresh-clone receipts from both machines with their scripts, the author's hand-check sheet.
- `layer13/` — blind re-formalisation from the prose (blind text, blind Lean statements, comparison reports, briefs).
- `layer14/` — Mathlib-only restatements with explicit witnesses, and their reports.
- `layer15/` — statements written from the classical literature by a model of a different family, with the comparison
  and scope reports; the proofs are in `QuadMiquel/L15Classical.lean` of each repository.
- `reviews/` — the independent reviews of the draft.
Machine names, IP addresses and home-directory paths are redacted throughout.
