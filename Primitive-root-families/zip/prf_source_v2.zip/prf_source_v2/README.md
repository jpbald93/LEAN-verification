# Source archive, version 2: Primitive roots modulo primes 2^kℓ+1, formalised in Lean 4: Chebyshev's base-10 criterion and the least primitive root of a safe prime

Paper key: Prime. Built 23 October 2026.

## Version-2 commits (published 23 October 2026)

| repository | branch | previous branch head | version-2 commit | tree |
|---|---|---|---|---|
| `primitive-root-families` | `main` | `5dd936f18e8914cd94750a9fabb5262fae197eba` | `b4ae30a94f5bc5bcba7e0143c239565af261038a` | https://github.com/jpbald93/primitive-root-families/tree/b4ae30a94f5bc5bcba7e0143c239565af261038a |

The version-2 commits add the Layer-14 and Layer-15 files; the paper states which earlier files changed.
The paper's line links for the version-1 theorems still point at the version-1 commits cited in the paper.

## Contents

- `prf.tex`, `prf.pdf`: the version-2 paper.
- `layer14_15/reports/`: Layer-14 report, Layer-15 comparison, integration report, paper-update report,
  the independent review(s) of the version-2 text and the fixes applied in response (whichever exist for this paper).
- `layer14_15/blind_writer/`: the textbook statements written by the blind writer (`classical_statements.txt`),
  its report (`CLASSICAL_REPORT.md`) and, where present, the statement collector's sources (`statements_sources.md`).
- `layer14_15/BLIND_TRANSCRIPT_AUDIT.md`: audit of the blind writers' tool calls (all runs, all papers).
- `SHA256SUMS.archive`: checksums of every file in this archive.

Machine names, IP addresses and home-directory paths are redacted throughout. No raw model transcripts are included.

## File list

- `layer14_15/reports/L14_REPORT.md`
- `layer14_15/reports/L15_COMPARE.md`
- `layer14_15/reports/INTEGRATE_REPORT.md`
- `layer14_15/reports/PAPER_UPDATE_REPORT.md`
- `layer14_15/reports/REVIEW_astra_L1415.md`
- `layer14_15/reports/FIXES_APPLIED.md`
- `layer14_15/reports/REVIEW_astra_L1415_r2.md`
- `layer14_15/blind_writer/classical_statements.txt`
- `layer14_15/blind_writer/CLASSICAL_REPORT.md`
- `layer14_15/blind_writer/statements_sources.md`
- `layer14_15/BLIND_TRANSCRIPT_AUDIT.md`
